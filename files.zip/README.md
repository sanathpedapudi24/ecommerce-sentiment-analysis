# Customer Sentiment Analysis & Reporting for E-commerce

Capstone project (Module 19, Week 8, 15 h). End-to-end system: text classification, SQL storage, Flask prediction API, Power BI dashboard.

## Document index

| File | Purpose |
|---|---|
| `REQUIREMENTS.md` | Functional and non-functional requirements, scope, acceptance criteria |
| `DATA.md` | Dataset, schema, label definition, splits |
| `ML_PIPELINE.md` | Preprocessing, features, models, tuning, evaluation |
| `DATABASE.md` | SQL schema, views, access rules |
| `API.md` | Flask endpoints, payloads, errors |
| `DASHBOARD.md` | Power BI pages, measures, visuals |
| `MLOPS.md` | Versioning, reproducibility, automation, monitoring |
| `ETHICS.md` | Bias, privacy, limitations |
| `ARCHITECTURE.md` | Components, data flow, repository layout |
| `TESTING.md` | Test plan and definition of done |
| `ROADMAP.md` | Task breakdown mapped to course modules |

## Stack

Python 3.11, NumPy, pandas, Matplotlib, Seaborn, scikit-learn, NLTK, joblib, SQLite (SQLAlchemy), Flask, Gunicorn, pytest, Power BI Desktop, Git, GitHub Actions.

## Quick start (target state)

```bash
make setup      # venv + dependencies
make data       # load raw CSV into SQL
make train      # run pipeline, write models/<version>/
make serve      # Flask API on :5000
make test       # pytest
make export     # SQL views -> reports/exports/*.csv for Power BI
```
